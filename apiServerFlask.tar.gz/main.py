from flask import Flask,jsonify,request
from flask_cors import CORS,cross_origin
from databaseHelper import DataBaseHelper
from datetime import datetime
from IoHelper import readFile
from systemInfo import SystemHelper
import os
import shlex

app = Flask(__name__)
cors = CORS(app, resources={r"/api/*": {"origins": "*"}})
dbHelper = DataBaseHelper('gpio.db')
systemHelper = SystemHelper()

@app.route("/")
def helloWorld():
    return "Hello, cross-origin-world!"

@app.route("/api/currentTemp")
@cross_origin()
def getCurrentTemperatures():
    
    temps = dbHelper.getTemperatureMinMaxCurrent(datetime.now())
    curTemps = {}
    curTemps['tempCave'] = temps['curCave'] 
    curTemps['tempExterieur']=temps['curExt']
    curTemps['tempChaudiere']=temps['curChaud']
    return jsonify(curTemps)

@app.route("/api/temperatures/<date>")
@cross_origin()
def getTemperatures(date):
    date = datetime.strptime(date,'%Y%m%d')
    return jsonify({'points':dbHelper.getTemperaturesOfDate(date)})

@app.route('/api/checkPassword/<password>', methods=['POST'])
@cross_origin()
def checkPassword(password):
    # data = request.json  
    data = {}
    data['authorized'] = (password=='motive')
    return jsonify(data)

@app.route('/api/shellcommand', methods=['POST'])
@cross_origin()
def shellcommand():
    
    command = request.form.get('cmdline')
    print(command)
    if(command=="infos") :
        output = systemHelper.getOsInfos()
        print(output)
    elif(command=="meminfo") :
        output = systemHelper.getMemoryUsage()
        print(output)
    else :
        stream = os.popen(command)
        output = stream.read()
    return jsonify({'output':output})


if __name__ == "__main__":
    app.run(debug=True)