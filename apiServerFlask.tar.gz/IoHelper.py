

def readFile(filename ):
    contenu =''
    f=None
    try:
        f = open(filename,"r", encoding = 'utf-8')
        contenu = f.read()
    except:
        contenu = ''
    finally:
        if(f!=None):
            f.close()
    return contenu

    